from ultralytics import YOLO
import cv2
import cvzone
import math

path1 = "Images/extra1.jpg"
img1 = cv2.imread(path1)
bc1 = cv2.resize(img1, (512, 512))

path2 = "Images/extra2.jpg"
img2 = cv2.imread(path2)
bc2 = cv2.resize(img2,(740,390) )

path3 = "Images/extra3.jpg"
img3 = cv2.imread(path3)
# bc3 = cv2.resize(img3, (640,640))

path4 = "Images/extra4.jpg"
img4 = cv2.imread(path4)
# bc4 = cv2.resize(img4, (600, 600))
bc4 = cv2.resize(img4, (500, 700))

path5 = "Images/extra5.jpg"
img5 = cv2.imread(path5)
bc5 = cv2.resize(img5, (900, 500))

path6 = "Images/extra6.jpg"
img6 = cv2.imread(path6)
bc6 = cv2.resize(img6, (768, 768))

# path7 = "Images/test7.jpg"
# img7 = cv2.imread(path7)
# bc7 = cv2.resize(img7, (640, 480),interpolation = cv2.INTER_LINEAR)


model1 = YOLO("../Yolo-Weights/best.pt")
model2 = YOLO("../Yolo-Weights/model7.pt")

classNames1 = ['Excavator', 'Gloves', 'Helmet', 'Ladder', 'Mask', 'NO-Helmet', 'NO-Mask', 'NO-Safety Vest', 'Person', 'SUV', 'Safety Cone', 'Safety Vest', 'bus', 'dump truck', 'fire hydrant', 'machinery', 'mini-van', 'sedan', 'semi', 'trailer', 'truck and trailer', 'truck', 'van', 'vehicle', 'wheel loader']
classNames2 = ['boot', 'glove', 'helmet', 'jacket', 'without glove', 'without helmet', 'without jacket']

bc1 = bc5
results1 = model1(bc1, stream=True)
for r in results1:
    boxes = r.boxes
    for box in boxes:
        cls = int(box.cls[0])
        conf = math.ceil((box.conf[0] * 100)) / 100
        if cls != 0 and cls != 8 and cls != 9 and cls != 10 and cls < 12 and cls!=3 :
            x1, y1, x2, y2 = box.xyxy[0]
            x1, y1, x2, y2 = int(x1), int(y1), int(x2), int(y2)
            w, h = x2 - x1, y2 - y1
            cv2.rectangle(bc1,(x1,y1),(x2,y2),(255,0,255),3)
            cvzone.putTextRect(bc1, f'{classNames1[cls]} {conf}', (max(0, x1), max(35, y1)), scale=0.6, thickness=1)

results2 = model2(bc1, stream=True)
for r in results2:
    boxes = r.boxes
    for box in boxes:
        cls = int(box.cls[0])
        conf = math.ceil((box.conf[0] * 100)) / 100
        if cls == 0 or cls == 4 :
            x1, y1, x2, y2 = box.xyxy[0]
            x1, y1, x2, y2 = int(x1), int(y1), int(x2), int(y2)
            w, h = x2 - x1, y2 - y1
            cv2.rectangle(bc1,(x1,y1),(x2,y2),(255,0,255),3)
            cvzone.putTextRect(bc1, f'{classNames2[cls]} {conf}', (max(0, x1), max(35, y1)), scale=0.6, thickness=1)

# ans.write(img)
cv2.imshow("Image", bc1)
cv2.waitKey(0)

cv2.destroyAllWindows()